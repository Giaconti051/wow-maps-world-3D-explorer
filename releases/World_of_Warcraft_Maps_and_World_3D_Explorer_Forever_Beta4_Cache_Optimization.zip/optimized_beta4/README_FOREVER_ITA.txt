World of Warcraft Maps and World 3D Explorer - Forever Native v2 + Water + Zephras Center Objects Beta 4

Questa versione mantiene il viewer originale e aggiunge nel medesimo menu:
  World of Warcraft: Forever -> Zephras Isle / Eastern Kingdoms / Kalimdor

Avvio:
1. Estrai l'intera cartella.
2. Avvia START_WOW_FOREVER_EXPLORER.bat.
3. Nel menu Games scegli World of Warcraft: Forever e una localita.
4. Le tile richieste vengono scaricate e verificate dal CDN Blizzard soltanto
   quando servono. Rimangono in WoW_Forever_CDN_Cache sul disco del programma.

Stato di questa build:
- Zephras, Eastern Kingdoms e Kalimdor usano WDT, geometria ADT e texture BLP
  della build Forever;
- streaming, LOD, render scaling, cache e comandi sono quelli del vecchio explorer;
- acqua Forever abilitata usando i materiali liquidi Classic compatibili;
- i nuovi LiquidType Forever assenti in Classic usano il materiale acqua generico Classic;
- M2, WMO, edifici e altri oggetti Forever sono abilitati sperimentalmente
  nelle mappe Eastern Kingdoms e Kalimdor; asset mancanti vengono saltati;
- Zephras Isle: terreno e acqua su tutte le tile; solo la tile centrale
  (28,26) prova ora a caricare i modelli M2 e gli edifici WMO. I due file
  di posizionamento sono stati scaricati e verificati; una parte degli M2
  viene risolta dagli indici gia presenti delle mappe continentali.
  Molti modelli e tutti gli edifici esclusivi dell'isola restano assenti
  dagli indici, e vengono saltati. Nessun modello e garantito finche non
  viene verificata la resa sul PC Windows con Edge.
- Il recupero delle risorse condivise e ora possibile anche tra manifest
  di mappe diverse, soltanto a parita di identificativo e dati CDN;
- Le risorse Forever gia scaricate vengono verificate con MD5 alla prima
  lettura del processo. Richieste successive allo stesso file evitano di
  ricalcolare l'MD5 se dimensione, date e identita del file sono invariate;
  un file modificato viene ricontrollato e, se corrotto, riscaricato.
  Questo riduce lavoro CPU ripetitivo nei ricaricamenti, non garantisce
  un aumento degli FPS quando il limite e la GPU o il renderer;
- Vanilla, The Burning Crusade e Wrath of the Lich King restano disponibili.

Build Forever fissata: wow_classic_beta 1.60.1.69893.
La cartella WoW_Archaeology_BrowserData e la cache restano accanto al programma.
Questa e una build sperimentale separata: conservare la Beta 2 funzionante.
Per riusare i dati senza riscaricarli, aggiornare i file del programma nella
stessa cartella lasciando intatte WoW_Forever_CDN_Cache e
WoW_Archaeology_BrowserData. Prima di sovrascrivere, conservare la Beta 3
come ZIP: la nuova versione si puo cosi annullare senza cancellare le cache.
