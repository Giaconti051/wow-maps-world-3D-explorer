@echo off
cd /d "%~dp0"

where py >nul 2>nul
if not errorlevel 1 (
    py -3 tools\wow-forever\forever-server.py
) else (
    python tools\wow-forever\forever-server.py
)
pause
